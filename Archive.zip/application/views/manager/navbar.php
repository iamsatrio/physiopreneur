<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li><a href="<?php echo base_url() ?>index.php/manager"><i class="icon icon-home"></i> <span>Home</span></a> </li>
    <li><a href="<?php echo base_url() ?>index.php/DataPegawai"><i class="icon icon-table"></i> <span>Data Pegawai</span></a> </li>
    <li><a href="<?php echo base_url() ?>index.php/laporanMan"><i class="icon icon-book"></i> <span>Laporan</span></a> </li>
  </ul>
</div>
