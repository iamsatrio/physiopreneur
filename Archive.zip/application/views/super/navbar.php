<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li><a href="<?php echo base_url() ?>index.php/superAdmin"><i class="icon icon-home"></i> <span>Home</span></a> </li>
    <li><a href="<?php echo base_url() ?>index.php/superAdmin/tampilDataManager"><i class="icon icon-table"></i> <span>Data Manager</span></a> </li>
    <li><a href="<?php echo base_url() ?>index.php/SuperAdmin/tampilLaporan"><i class="icon icon-book"></i> <span>Laporan</span></a> </li>
  </ul>
</div>
